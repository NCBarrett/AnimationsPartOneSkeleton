package com.example.bitamirshafiee.animationspartoneskeleton

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class CircularPositioning : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_circular_positioning)
    }
}
