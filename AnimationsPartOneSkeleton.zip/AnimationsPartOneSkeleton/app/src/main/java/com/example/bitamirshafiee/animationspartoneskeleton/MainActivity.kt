package com.example.bitamirshafiee.animationspartoneskeleton

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun constraintSetFirstExample(view : View){}
    fun constraintSetSecondExample(view: View){}
    fun placeHolderExample(view: View){}
    fun circlePositioning(view: View){}
}
